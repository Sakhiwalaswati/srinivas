package com.flp.fms.dao;

import java.util.List;

import com.flp.ems.domain.Category;
import com.flp.ems.domain.Film;
import com.flp.ems.domain.Language;

public interface IFilmDao
{

	boolean AddFilm(Film film);

	void UpdateFilm();

	boolean RemoveFilm(int id);

	Film SearchFilm(int id);

	List<Film> getAllFilm();

	Language findLanguagebyName(String string);

	Category findCategoryByName(String string);

}