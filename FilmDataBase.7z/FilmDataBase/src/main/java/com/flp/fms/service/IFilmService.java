package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.flp.ems.domain.Film;

public interface IFilmService
{

	boolean AddFilm(Map<String, Object> film_Detail);// To Add Film Details
	
	void ModifyFilm();                               //To Modify Film Details

	Film SearchFilm(int id);                         //To Search Film Details

	boolean RemoveFilm(int Id);                      ////To Remove Film Details
	
	List<Film> getAllFilm();                         //To Get All Film Details

	

}
