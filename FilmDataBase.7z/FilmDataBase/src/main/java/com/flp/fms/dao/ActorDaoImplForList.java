package com.flp.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Category;
import com.flp.ems.domain.Film;
import com.flp.ems.domain.Language;

public class ActorDaoImplForList implements IActorDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");

	EntityManager em = emf.createEntityManager();


	@Override
	public Actor AddActor(Actor actor) 
	{

		Actor actor1=findActorByName(actor.getFirst_name(),actor.getLast_name());
		if(actor1 == null)
		{
			em.getTransaction().begin();
			em.persist(actor);
			em.getTransaction().commit();
			System.out.println("Actor added successfully");
			return actor;
		}
		else
		{
			em.getTransaction().begin();
			em.persist(actor1);
			em.getTransaction().commit();
			System.out.println("Actor already exists");
			return actor1;
		}

	}

	private Actor findActorByName(String first_name, String last_name) {
		
		TypedQuery<Actor> query = em.createQuery("Select a from Actor a",Actor.class);

		for(Actor a:query.getResultList())
		{
		if(a.getFirst_name().equals(first_name) && a.getLast_name().equals(last_name))
		{
		return a;
		}
		}
		return null;


	}

	@Override
	public void UpdateActor() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean RemoveActor(int id)
	{
		Actor actor = SearchActor(id);
		if(actor !=null)
		{
			em.getTransaction().begin();
			em.remove(actor);
			em.getTransaction().commit();
			em.remove(actor);
			return true;
		}
		return false;
	}

	@Override
	public Actor SearchActor(int id) 
	{
		return em.find(Actor.class, id);
	}

	@Override
	public List<Actor> getAllActor()
	{
		System.out.println("\n");
		TypedQuery<Actor> query = em.createQuery("Select a from Actor a",Actor.class);
		return query.getResultList();
	}
	
	public Category findCategoryByName(String cat)
	{
		TypedQuery<Category> query = em.createQuery("Select l from Language l",Category.class);
		
		System.out.println(cat);
		System.out.println(query.getResultList());
		List<Category> categories=query.getResultList();
		for(Category l:categories)
		{
			System.out.println(l);
			if(l.getName().equals(cat))
			{
				return l;
			}
		}
		return null;
	}
}
