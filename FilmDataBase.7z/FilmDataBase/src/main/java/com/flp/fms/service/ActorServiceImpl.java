package com.flp.fms.service;

import java.util.List;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Film;
import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IFilmDao;

public class ActorServiceImpl implements  IActorService
{
	IActorDao actorRepo=new ActorDaoImplForList();
	
	@Override
	public Actor AddActor(String firstName, String lastName)
	{
		Actor actor=new Actor();
		actor.setFirst_name(firstName);
		actor.setLast_name(lastName);
		System.out.println(actor);
		return actorRepo.AddActor(actor);		
		
	}
	@Override
	public void ModifyActor()
	{
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean RemoveActor(int id) 
	{
		
		return actorRepo.RemoveActor(id);
	}
	@Override
	public Actor SearchActor(int id)
	{
		// TODO Auto-generated method stub
		return actorRepo.SearchActor(id);
	}
	@Override
	public List<Actor> getAllActor() 
	{
		// TODO Auto-generated method stub
		return actorRepo.getAllActor();
	}	

}