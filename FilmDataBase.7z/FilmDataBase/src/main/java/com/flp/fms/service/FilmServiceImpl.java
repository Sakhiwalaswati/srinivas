package com.flp.fms.service;


import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.internal.util.compare.CalendarComparator;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Category;
import com.flp.ems.domain.Film;
import com.flp.ems.domain.Language;

import com.flp.fms.dao.ActorDaoImplForList;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;

public class FilmServiceImpl implements  IFilmService 
{

	IFilmDao filmRepo=new FilmDaoImplForList();
	
	
	@Override
	public boolean AddFilm(Map<String, Object> film_Detail) 
	{

		Film film=new Film();
				
		Category category1=filmRepo.findCategoryByName((String) film_Detail.get("category"));
		if(category1==null)
		{
			Category category=new Category();
			category.setName((String) film_Detail.get("category"));
			film.setCategory(category);
			
		}
		else
		{
			film.setCategory(category1);
		}
		

		Language language1=filmRepo.findLanguagebyName((String) film_Detail.get("lang"));
		if(language1==null)
		{
			Language language=new Language();
			language.setName((String) film_Detail.get("lang"));
			film.setLanguage(language);
		}
		else
		{
			film.setLanguage(language1);
		}
		
		List actors=(List) film_Detail.get("actors");

		System.out.println(film.getActor());
		
		for(int x=0;x<actors.size();x++)
		{

			Actor temp=new Actor();
			temp.setFirst_name((String)((Map<String,Object>) actors.get(x)).get("first_name"));
			temp.setLast_name((String)((Map<String,Object>) actors.get(x)).get("Last_name"));
            film.getActor().add(temp);
		}
		film.setRelease_year( (Date) film_Detail.get("date"));
		film.setDescription((String) film_Detail.get("des"));
  		film.setTitle((String) film_Detail.get("title"));
		film.setRental_duration((double) ( film_Detail.get("rental_duration")));
		film.setLength((double) ( film_Detail.get("Lenght")));
		film.setCost((double) film_Detail.get("cost"));
		film.setRating((double) film_Detail.get("rate"));
		return filmRepo.AddFilm(film);
	}
	@Override
	public void ModifyFilm()
	{
		
	}
	@Override
	public boolean RemoveFilm(int Id)
	{
		return filmRepo.RemoveFilm(Id);
	}
	@Override
	public Film SearchFilm(int id)
	{
		return filmRepo.SearchFilm(id);

	}
	@Override
	public List<Film> getAllFilm() 
	{
		return filmRepo.getAllFilm();

	}
}















