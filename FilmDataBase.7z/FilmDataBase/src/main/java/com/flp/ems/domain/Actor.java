package com.flp.ems.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
@Entity
public class Actor {
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	private int actor_id;

	String  first_name;
	String last_name;
	@ManyToMany(fetch = FetchType.LAZY,cascade = {CascadeType.ALL},mappedBy="actor")
	private Set<Film> film=new HashSet<Film>();
	
	public Actor(){}
	
	
	
	
	public int getActor_id() {
		return actor_id;
	}


	public String getFirst_name() {
		return first_name;
	}




	public  void setFirst_name(String first_name) {
		this.first_name = first_name;
	}




	public String getLast_name() {
		return last_name;
	}




	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}




	public Set<Film> getFilm() {
		return film;
	}




	public void setFilm(Set<Film> film) {
		this.film = film;
	}




	@Override
	public String toString() {
		return "Actor [actor_id=" + actor_id + ", first_name=" + first_name + ", last_name=" + last_name + ", film="
				+ film + "]";
	}
	

}
