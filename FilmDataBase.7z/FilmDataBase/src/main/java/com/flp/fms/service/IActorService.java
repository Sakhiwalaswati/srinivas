package com.flp.fms.service;

import java.util.List;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Film;

public interface IActorService 
{
	public Actor AddActor(String first_name,String last_name); //To Add Actor Details
	
	void ModifyActor();                                 //To Modify Actor Details

	boolean RemoveActor(int id);                        //To Remove Actor Details

	Actor SearchActor(int id);                          //To Search Actor Details

	List<Actor> getAllActor();                         // To Get Actor Details 



}
