package com.flp.ems.domain;


import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Category {

	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	int category_id;
	private String name;
	
	@OneToMany(fetch = FetchType.LAZY,cascade = {CascadeType.ALL},mappedBy="category")
	private Set<Film> film=new HashSet<Film>();
	
	public int getCategory_id() {
		return category_id;
	}

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public Set<Film> getFilm() {
		return film;
	}
	public void setFilm(Set<Film> film) {
		this.film = film;
	}
	@Override
	public String toString() {
		return "Category [category_id=" + category_id + ", name=" + name + ", film=" + film + "]";
	}





}
