package com.flp.ems.domain;



import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
@Entity
public class Film {
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	private int film_id;
	private String title;
	private String description;
	private Date release_year;
	


	private double rental_duration;

	private double length;
	private double cost;
	private double rating;

	@ManyToOne(fetch = FetchType.LAZY,cascade = {CascadeType.ALL})
	@JoinColumn(name="language_id")
	private Language language;


	@ManyToOne(fetch = FetchType.LAZY,cascade = {CascadeType.ALL})
	@JoinTable(name="film_category",joinColumns={@JoinColumn (name="film_id",referencedColumnName="film_id")},inverseJoinColumns={@JoinColumn(name="category_id",referencedColumnName="category_id")})
	private Category category;


	@ManyToMany(fetch = FetchType.LAZY,cascade = {CascadeType.ALL})
	@JoinTable(name="film_actor",joinColumns={@JoinColumn(name="film_id",referencedColumnName="film_id")},inverseJoinColumns={@JoinColumn(name="actor_id",referencedColumnName="actor_id")})
	private List<Actor> actor=new ArrayList<Actor>();


	public int getFilm_id() {
		return film_id;
	}


	public void setFilm_id(int film_id) {
		this.film_id = film_id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	

	public Date getRelease_year() {
		return release_year;
	}


	public void setRelease_year(Date release_year) {
		this.release_year = release_year;
	}


	public double getRental_duration() {
		return rental_duration;
	}


	public void setRental_duration(double rental_duration) {
		this.rental_duration = rental_duration;
	}


	public double getLength() {
		return length;
	}


	public void setLength(double length) {
		this.length = length;
	}


	public double getCost() {
		return cost;
	}


	public void setCost(double cost) {
		this.cost = cost;
	}


	public double getRating() {
		return rating;
	}


	public void setRating(double rating) {
		this.rating = rating;
	}


	public Language getLanguage() {
		return language;
	}


	public void setLanguage(Language language) {
		this.language = language;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	public List<Actor> getActor() {
		return actor;
	}


	public void setActor(List<Actor> list) {
		this.actor = list;
	}


	@Override
	public String toString() {
		return "Film [film_id=" + film_id + ", title=" + title + ", description=" + description + ", release_year="
				+ release_year + ", rental_duration=" + rental_duration + ", length=" + length + ", cost=" + cost
				+ ", rating=" + rating + ", language=" + language + ", category=" + category + ", actor=" + actor + "]";
	}


	






}
