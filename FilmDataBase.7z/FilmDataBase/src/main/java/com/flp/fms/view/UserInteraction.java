package com.flp.fms.view;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Film;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class UserInteraction 
{
	
	IFilmService filmService;
	IActorService actorService;
	Scanner sc=new Scanner(System.in);
	UserInteraction()
	{

		this.filmService=new FilmServiceImpl();
		this.actorService=new ActorServiceImpl(); 
	}
	public void AddFilm() throws ParseException
	{
		

		Map<String,Object> Film_Detail=new HashMap();


		System.out.print("Enter the Title of the Film :");
		Film_Detail.put("title",sc.next());

		System.out.print("Enter the description of the Film :");
		Film_Detail.put("des",sc.next());

		System.out.print("Enter the release year of the Film :");
		String startDate=sc.next();
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-mm-yyyy");
		java.util.Date date = sdf1.parse(startDate);
		java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());  
		Film_Detail.put("date",sqlStartDate);

		System.out.print("Enter the rental duration of the Film :");
		Film_Detail.put( "rental_duration",sc.nextDouble());

		System.out.print("Enter the length of the Film :");
		Film_Detail.put("Lenght",sc.nextDouble());


		System.out.print("Enter the replacement cost of the Film :");
		Film_Detail.put("cost",sc.nextDouble());


		System.out.print("Enter the rating of the Film :");
		Film_Detail.put("rate",sc.nextDouble());

		System.out.print("Enter the language of the Film :");
		Film_Detail.put("lang",sc.next());

		System.out.print("Enter the Category of the Film :");
		Film_Detail.put("category",sc.next());

		System.out.print("Enter the Number of the Actor in the film :");
		int x=sc.nextInt();


		List actor=new ArrayList();
		for(int i=0;i<x;i++)
		{
			Map<String,String> actors=new HashMap<String,String>();
			System.out.print("Enter the First name of the Actor :");
			actors.put("first_name",sc.next() );
			System.out.print("Enter the Last Name of the Actor :");
			actors.put("Last_name",sc.next() );

			actor.add( actors);
		}

		Film_Detail.put("actors",actor);

		filmService.AddFilm(Film_Detail);
	}
	public void ModifyFilm()
	{
		System.out.print("Enter the Film id :");
		int Id=sc.nextInt();
	}
	public void RemoveFilm() 
	{
		System.out.print("Enter the Film id :");
		int Id=sc.nextInt();
		if(filmService.RemoveFilm(Id))
		{
			System.out.println("Remove Successfully");
		}
		else
		{
			System.out.println("Unsuccessfull Operation");
		}

	}
	public void SearchFilm() 
	{
		System.out.print("Enter the Film id :");
		int Id=sc.nextInt();
		Film film=filmService.SearchFilm(Id);
		if(film !=null)
		{
			System.out.println(film);
		}
		else
		{

			System.out.println("no Such Film Found");
		}
	}
	public void getAllFilm() 
	{
		List<Film> films= filmService.getAllFilm();
		System.out.println(films);

	}
	public Actor AddActor()
	{

		System.out.print("Enter the actor first name :");
		String firstName=sc.next();
		System.out.print("Enter the actor last name :");
		String lastName=sc.next();
		System.out.println("Actor added successfully");
		return actorService.AddActor(firstName,lastName);

	}

	public void ModifyActor()
	{
		// TODO Auto-generated method stub

	}

	public void RemoveActor() 
	{
		System.out.print("Enter the Actor id :");
		int Id=sc.nextInt();
		if(actorService.RemoveActor(Id))
		{
			System.out.println("Remove Successfully");
		}
		else
		{
			System.out.println("Unsuccessfull Operation");
		}

	}

	public void SearchActor()
	{
		System.out.print("Enter the Actor id :");
		int Id=sc.nextInt();
		Actor actor=actorService.SearchActor(Id);
		if(actor !=null)
		{
			System.out.println(actor);
		}
		else
		{
			
			System.out.println("no Such actor Found");
		}


	}
	void getAllActor() 
	{
		 List<Actor> actors= actorService.getAllActor();
		 System.out.println(actors);

	}

}
