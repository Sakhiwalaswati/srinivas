package com.flp.fms.dao;

import java.util.List;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Category;
import com.flp.ems.domain.Film;
import com.flp.ems.domain.Language;

public interface IActorDao 
{

 	//boolean AddActor(Actor actor);
	
	public Actor AddActor(Actor actor);

	void UpdateActor();

	boolean RemoveActor(int id);

	Actor SearchActor(int id);

	List<Actor> getAllActor();
	
	Category findCategoryByName(String string);

}