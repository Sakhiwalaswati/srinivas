
package com.flp.ems.domain;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity

public class Language {
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	int language_id;
	private String name;
	
	@OneToMany(fetch = FetchType.LAZY,cascade = {CascadeType.ALL},mappedBy="language")
	private Set<Film> film=new HashSet();
	public int getLanguage_id() {
		return language_id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Set<Film> getFilm() {
		return film;
	}
	public void setFilm(Set<Film> film) {
		this.film = film;
	}

	@Override
	public String toString() {
		return "Language [language_id=" + language_id + ", name=" + name + ", film=" + film + "]";
	}
	
	


}
