package com.flp.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.flp.ems.domain.Category;
import com.flp.ems.domain.Film;
import com.flp.ems.domain.Language;

public class FilmDaoImplForList implements IFilmDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
	EntityManager em = emf.createEntityManager();


	@Override
	public boolean AddFilm(Film film) {

		if(film != null)
		{
			em.getTransaction().begin();
			em.persist(film);
			em.getTransaction().commit();
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public void UpdateFilm() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean RemoveFilm(int id) {
		Film film = SearchFilm(id);
		
		if(film !=null)
		{
			em.getTransaction().begin();
			em.remove(film);
			em.getTransaction().commit();
			return true;
		}
		return false;
	}

	@Override
	public Film SearchFilm(int id) {

		return em.find(Film.class, id);

	}

	@Override
	public List<Film> getAllFilm() {
		System.out.println("\n");
		TypedQuery<Film> query = em.createQuery("Select e from Film e",Film.class);
		return query.getResultList();

	}
	public Language findLanguagebyName(String name)
	{
		TypedQuery<Language> query = em.createQuery("Select l from Language l",Language.class);
		
		System.out.println(name);
		System.out.println(query.getResultList());
		List<Language> languages=query.getResultList();
		for(Language l:languages)
		{
			System.out.println(l);
			if(l.getName().equals(name))
			{
				return l;
			}
		}
		return null;
	}

	@Override
	public Category findCategoryByName(String string)
	{
		TypedQuery<Category> query = em.createQuery("Select l from Category l",Category.class);
				
		List<Category> category=query.getResultList();
		for(Category l:category)
		{
			System.out.println(l);
			if(l.getName().equals(string))
			{
				return l;
			}
		}
		return null;
	}
}
